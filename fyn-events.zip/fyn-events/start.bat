@echo off
cd /d "%~dp0"
echo Starting Find Your North events board...
echo Open http://localhost:4173
node server.js
pause
